package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Equipment {
	
}
